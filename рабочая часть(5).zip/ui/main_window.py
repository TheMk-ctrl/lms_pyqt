"""
Главное окно: список заметок пользователя + управление ими.
Использует QSqlTableModel + QTableView (как требует задание).
"""

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableView, QLineEdit,
    QMessageBox, QStatusBar, QToolBar, QComboBox, QFileDialog
)
from PyQt6.QtSql import QSqlQueryModel, QSqlQuery
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction

from ui.note_dialog import NoteDialog
from ui.view_note_dialog import ViewNoteDialog
from ui.cipher_demo_window import CipherDemoWindow



class MainWindow(QMainWindow):
    def __init__(self, user_id: int, username: str):
        super().__init__()
        self.user_id = user_id
        self.username = username

        self.setWindowTitle(f"CryptoNotes — {username}")
        self.setMinimumSize(900, 550)

        self._build_toolbar()
        self._build_central()
        self._build_statusbar()

        self._load_model()

    # ──────────────── Построение UI ────────────────

    def _build_toolbar(self):
        toolbar = QToolBar("Основная панель")
        self.addToolBar(toolbar)

        act_add = QAction("Добавить", self)
        act_add.setToolTip("Создать новую заметку")
        act_add.triggered.connect(self._on_add)
        toolbar.addAction(act_add)

        act_edit = QAction("Изменить", self)
        act_edit.setToolTip("Редактировать выбранную заметку")
        act_edit.triggered.connect(self._on_edit)
        toolbar.addAction(act_edit)

        act_del = QAction("Удалить", self)
        act_del.setToolTip("Удалить выбранную заметку")
        act_del.triggered.connect(self._on_delete)
        toolbar.addAction(act_del)

        toolbar.addSeparator()

        act_cipher = QAction("Демо шифрования", self)
        act_cipher.setToolTip("Попробовать алгоритмы шифрования вживую")
        act_cipher.triggered.connect(self._open_cipher_demo)
        toolbar.addAction(act_cipher)

        toolbar.addSeparator()

        act_export = QAction("Экспорт в txt", self)
        act_export.triggered.connect(self._export_to_txt)
        toolbar.addAction(act_export)

        toolbar.addSeparator()

        act_stickers = QAction("Стикеры", self)
        act_stickers.setToolTip("Открыть все заметки как стикеры на рабочем столе")
        act_stickers.triggered.connect(self._open_stickers)
        toolbar.addAction(act_stickers)

    def _build_central(self):
        central = QWidget()
        self.setCentralWidget(central)
        vbox = QVBoxLayout(central)

        # Строка поиска + фильтр по категории
        filter_row = QHBoxLayout()

        filter_row.addWidget(QLabel("Поиск:"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Введите часть заголовка...")
        self.search_edit.textChanged.connect(self._on_search)
        filter_row.addWidget(self.search_edit)

        filter_row.addWidget(QLabel("Категория:"))
        self.cat_combo = QComboBox()
        self.cat_combo.setMinimumWidth(130)
        self.cat_combo.currentIndexChanged.connect(self._on_category_filter)
        filter_row.addWidget(self.cat_combo)

        vbox.addLayout(filter_row)

        # Таблица заметок
        self.table_view = QTableView()
        self.table_view.setSortingEnabled(True)
        self.table_view.setSelectionBehavior(
            QTableView.SelectionBehavior.SelectRows
        )
        self.table_view.setEditTriggers(
            QTableView.EditTrigger.NoEditTriggers
        )
        self.table_view.doubleClicked.connect(self._on_view)
        vbox.addWidget(self.table_view)

        # Нижняя строка с кнопками
        btn_row = QHBoxLayout()
        for label, slot in [
            ("Добавить", self._on_add),
            ("Изменить", self._on_edit),
            ("Удалить",  self._on_delete),
        ]:
            btn = QPushButton(label)
            btn.clicked.connect(slot)
            btn_row.addWidget(btn)
        btn_row.addStretch()
        vbox.addLayout(btn_row)

    def _build_statusbar(self):
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage(f"Добро пожаловать, {self.username}!")

    # ──────────────── Модель данных ────────────────

    # SQL-запрос для отображения заметок с названием категории вместо ID
    _NOTES_SQL = """
        SELECT
            n.id          AS id,
            n.title       AS Заголовок,
            COALESCE(c.title, '—') AS Категория,
            n.cipher      AS Шифр,
            n.created_at  AS Создано
        FROM notes n
        LEFT JOIN categories c ON c.id = n.category_id
        WHERE n.user_id = {user_id} {extra}
        ORDER BY n.created_at DESC
    """

    def _load_model(self):
        """Создаём QSqlQueryModel с JOIN и привязываем к QTableView."""
        self.model = QSqlQueryModel(self)
        self._refresh_model()

        self.table_view.setModel(self.model)
        # Прячем колонку id (она первая, индекс 0)
        self.table_view.setColumnHidden(0, True)
        self.table_view.horizontalHeader().setStretchLastSection(True)

        # Заполняем комбобокс категорий
        self._fill_categories()
        self._update_status()

    def _refresh_model(self, extra: str = ""):
        """Перезапускает SQL-запрос модели."""
        sql = self._NOTES_SQL.format(user_id=self.user_id, extra=extra)
        self.model.setQuery(sql)

    def _fill_categories(self):
        self.cat_combo.blockSignals(True)
        self.cat_combo.clear()
        self.cat_combo.addItem("Все категории", -1)

        query = QSqlQuery("SELECT id, title FROM categories ORDER BY title")
        while query.next():
            self.cat_combo.addItem(query.value(1), query.value(0))

        self.cat_combo.blockSignals(False)

    def _update_status(self):
        count = self.model.rowCount()
        self.status.showMessage(f"Заметок: {count}  |  Пользователь: {self.username}")

    # ──────────────── Поиск и фильтр ────────────────

    def _on_search(self, text: str):
        self._apply_filter(text, self.cat_combo.currentData())

    def _on_category_filter(self):
        self._apply_filter(self.search_edit.text(), self.cat_combo.currentData())

    def _apply_filter(self, search: str, cat_id):
        extra_parts = []

        if search:
            # Экранируем одиночную кавычку во избежание ошибок
            safe = search.replace("'", "''")
            extra_parts.append(f"AND n.title LIKE '%{safe}%'")

        if cat_id and cat_id != -1:
            extra_parts.append(f"AND n.category_id = {cat_id}")

        self._refresh_model(" ".join(extra_parts))
        self._update_status()

    # ──────────────── CRUD ────────────────

    def _selected_note_id(self) -> int | None:
        idx = self.table_view.currentIndex()
        if not idx.isValid():
            return None
        # Колонка 0 — это id (скрытая), берём именно её
        return self.model.data(self.model.index(idx.row(), 0))

    def _on_view(self):
        """Просмотр заметки (двойной клик) — только чтение."""
        note_id = self._selected_note_id()
        if note_id is None:
            return
        dlg = ViewNoteDialog(note_id, parent=self)
        dlg.exec()

    def _on_add(self):
        dlg = NoteDialog(self.user_id, parent=self)
        if dlg.exec():
            self._refresh_model()
            self._fill_categories()
            self._update_status()

    def _on_edit(self):
        note_id = self._selected_note_id()
        if note_id is None:
            QMessageBox.information(self, "Выберите заметку", "Сначала выберите заметку в таблице.")
            return

        dlg = NoteDialog(self.user_id, note_id=note_id, parent=self)
        if dlg.exec():
            self._refresh_model()
            self._update_status()

    def _on_delete(self):
        note_id = self._selected_note_id()
        if note_id is None:
            QMessageBox.information(self, "Выберите заметку", "Сначала выберите заметку в таблице.")
            return

        # Получаем заголовок для подтверждения (колонка 1 = Заголовок)
        idx = self.table_view.currentIndex()
        title = self.model.data(self.model.index(idx.row(), 1))

        reply = QMessageBox.question(
            self, "Удаление",
            f"Удалить заметку «{title}»?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            query = QSqlQuery()
            query.prepare("DELETE FROM notes WHERE id = ?")
            query.addBindValue(note_id)
            query.exec()
            self._refresh_model()
            self._update_status()
            self.status.showMessage(f"Заметка «{title}» удалена.")

    # ──────────────── Экспорт ────────────────

    def _export_to_txt(self):
        """Экспортирует все заметки пользователя в текстовый файл."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить заметки", f"{self.username}_notes.txt",
            "Текстовые файлы (*.txt)"
        )
        if not path:
            return

        query = QSqlQuery()
        query.prepare("""
            SELECT n.title, n.content, n.cipher, c.title, n.created_at
            FROM notes n
            LEFT JOIN categories c ON c.id = n.category_id
            WHERE n.user_id = ?
            ORDER BY n.created_at DESC
        """)
        query.addBindValue(self.user_id)
        query.exec()

        lines = [f"Заметки пользователя: {self.username}\n{'=' * 40}\n"]
        while query.next():
            title, content, cipher, cat, created = (
                query.value(i) for i in range(5)
            )
            lines.append(
                f"[{created}] {title}\n"
                f"Категория: {cat or '—'}  |  Шифр: {cipher}\n"
                f"{content}\n{'-' * 40}\n"
            )

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            QMessageBox.information(self, "Готово", f"Экспорт завершён:\n{path}")
        except OSError as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # ──────────────── Демо шифрования ────────────────

    def _open_cipher_demo(self):
        # parent=None — открывается как отдельное независимое окно
        self.cipher_win = CipherDemoWindow(parent=None)
        self.cipher_win.show()

    def _open_stickers(self):
        from ui.sticker_board import StickerBoard
        self.sticker_board = StickerBoard(self.user_id, parent=None)
        self.sticker_board.show()
