"""
Доска стикеров — открывает все заметки пользователя как стикеры на рабочем столе.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QCheckBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtSql import QSqlQuery

from ui.sticker_widget import StickerWidget


class StickerBoard(QWidget):
    """
    Небольшая панель управления стикерами.
    Сами стикеры — отдельные окна, которые висят поверх рабочего стола.
    """

    def __init__(self, user_id: int, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.stickers: dict[int, StickerWidget] = {}  # note_id → виджет

        self.setWindowTitle("Стикеры")
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setFixedWidth(260)

        self._build_ui()
        self._load_stickers()

    # ──────────────── UI панели ────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Стикеры на рабочем столе")
        title.setStyleSheet("font-weight: bold; font-size: 13px;")
        layout.addWidget(title)

        hint = QLabel("Перетаскивайте стикеры куда хотите.\nТекст редактируется прямо на стикере.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color: #666; font-size: 11px;")
        layout.addWidget(hint)

        # Список заметок с чекбоксами
        self.check_layout = QVBoxLayout()
        layout.addLayout(self.check_layout)

        btn_row = QHBoxLayout()

        show_all_btn = QPushButton("Показать все")
        show_all_btn.clicked.connect(self._show_all)
        btn_row.addWidget(show_all_btn)

        hide_all_btn = QPushButton("Скрыть все")
        hide_all_btn.clicked.connect(self._hide_all)
        btn_row.addWidget(hide_all_btn)

        layout.addLayout(btn_row)

        close_btn = QPushButton("Закрыть панель")
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)

    def _load_stickers(self):
        """Загружает заметки из БД и создаёт стикеры."""
        # Очищаем старые чекбоксы
        while self.check_layout.count():
            item = self.check_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        query = QSqlQuery()
        query.prepare("""
            SELECT id, title, content, cipher, color, sticker_x, sticker_y
            FROM notes
            WHERE user_id = ?
            ORDER BY created_at DESC
        """)
        query.addBindValue(self.user_id)
        query.exec()

        while query.next():
            note_id  = query.value(0)
            title    = query.value(1)
            content  = query.value(2)
            cipher   = query.value(3)
            color    = query.value(4) or "#FFFACD"
            sx       = query.value(5)
            sy       = query.value(6)

            # Чекбокс в панели управления
            cb = QCheckBox(title)
            cb.setChecked(False)
            # Цветной квадратик рядом с названием
            cb.setStyleSheet(
                f"QCheckBox::indicator {{ width:14px; height:14px; "
                f"background:{color}; border:1px solid #999; border-radius:2px; }}"
                f"QCheckBox::indicator:checked {{ border:2px solid #333; }}"
            )
            cb.toggled.connect(
                lambda checked, nid=note_id, t=title, c=content,
                       ci=cipher, cl=color, x=sx, y=sy:
                self._toggle_sticker(checked, nid, t, c, ci, cl, x, y)
            )
            self.check_layout.addWidget(cb)

        self.adjustSize()

    # ──────────────── Управление стикерами ────────────────

    def _toggle_sticker(self, show: bool, note_id: int, title: str,
                        content: str, cipher: str, color: str,
                        x, y):
        if show:
            if note_id not in self.stickers:
                sticker = StickerWidget(
                    note_id=note_id,
                    title=title,
                    content=content,
                    cipher=cipher,
                    color=color,
                    x=x if x != "" else None,
                    y=y if y != "" else None,
                    on_close_callback=self._on_sticker_closed
                )
                sticker.show()
                self.stickers[note_id] = sticker
        else:
            if note_id in self.stickers:
                self.stickers[note_id].close()
                del self.stickers[note_id]

    def _on_sticker_closed(self, note_id: int):
        """Вызывается когда пользователь закрывает стикер крестиком."""
        if note_id in self.stickers:
            del self.stickers[note_id]
        # Снимаем галочку в панели
        for i in range(self.check_layout.count()):
            widget = self.check_layout.itemAt(i).widget()
            if isinstance(widget, QCheckBox):
                # Находим нужный чекбокс по порядку — проще снять все и перезагрузить
                break
        self._load_stickers()

    def _show_all(self):
        for i in range(self.check_layout.count()):
            widget = self.check_layout.itemAt(i).widget()
            if isinstance(widget, QCheckBox):
                widget.setChecked(True)

    def _hide_all(self):
        for i in range(self.check_layout.count()):
            widget = self.check_layout.itemAt(i).widget()
            if isinstance(widget, QCheckBox):
                widget.setChecked(False)

    def closeEvent(self, event):
        """При закрытии панели скрываем все стикеры."""
        for sticker in list(self.stickers.values()):
            sticker.close()
        self.stickers.clear()
        super().closeEvent(event)
