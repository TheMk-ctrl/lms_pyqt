"""
Диалог создания / редактирования заметки.
Поддерживает шифрование прямо при сохранении.
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QTextEdit, QComboBox, QPushButton,
    QMessageBox, QCheckBox, QColorDialog
)
from PyQt6.QtGui import QColor
from PyQt6.QtSql import QSqlQuery

from core.cipher import encrypt, decrypt, cipher_names


class NoteDialog(QDialog):
    def __init__(self, user_id: int, note_id: int | None = None, parent=None):
        super().__init__(parent)
        self.user_id = user_id
        self.note_id = note_id  # None = новая заметка
        self.is_edit = note_id is not None

        self.setWindowTitle("Редактировать заметку" if self.is_edit else "Новая заметка")
        self.setMinimumWidth(480)

        self._build_ui()

        if self.is_edit:
            self._load_note()

    # ──────────────── UI ────────────────

    def _build_ui(self):
        layout = QVBoxLayout(self)

        # Заголовок
        layout.addWidget(QLabel("Заголовок:"))
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText("Краткое название заметки...")
        layout.addWidget(self.title_edit)

        # Категория
        row = QHBoxLayout()
        row.addWidget(QLabel("Категория:"))
        self.cat_combo = QComboBox()
        self._fill_categories()
        row.addWidget(self.cat_combo)
        row.addStretch()
        layout.addLayout(row)

        # Текст заметки
        layout.addWidget(QLabel("Текст заметки:"))
        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("Введите текст...")
        self.content_edit.setMinimumHeight(160)
        layout.addWidget(self.content_edit)

        # Шифрование
        cipher_row = QHBoxLayout()
        cipher_row.addWidget(QLabel("Шифрование:"))

        self.cipher_combo = QComboBox()
        for cid, cname in cipher_names().items():
            self.cipher_combo.addItem(cname, cid)
        cipher_row.addWidget(self.cipher_combo)

        cipher_row.addWidget(QLabel("Ключ (для XOR):"))
        self.key_edit = QLineEdit("secret")
        self.key_edit.setMaximumWidth(100)
        cipher_row.addWidget(self.key_edit)
        cipher_row.addStretch()
        layout.addLayout(cipher_row)

        # Цвет стикера
        color_row = QHBoxLayout()
        color_row.addWidget(QLabel("Цвет стикера:"))

        # Набор готовых цветов
        self.selected_color = "#FFFACD"
        self._color_buttons = []
        preset_colors = [
            ("#FFFACD", "Жёлтый"),
            ("#FFD1DC", "Розовый"),
            ("#B5EAD7", "Зелёный"),
            ("#C7CEEA", "Голубой"),
            ("#FFDAC1", "Оранжевый"),
            ("#E2F0CB", "Лайм"),
            ("#F8F8F8", "Белый"),
        ]
        for hex_color, tip in preset_colors:
            btn = QPushButton()
            btn.setFixedSize(24, 24)
            btn.setToolTip(tip)
            btn.setStyleSheet(
                f"background:{hex_color}; border:2px solid #aaa; border-radius:4px;"
            )
            btn.clicked.connect(lambda _, c=hex_color: self._pick_preset(c))
            color_row.addWidget(btn)
            self._color_buttons.append((btn, hex_color))

        # Кнопка произвольного цвета
        self.custom_color_btn = QPushButton("Свой цвет...")
        self.custom_color_btn.clicked.connect(self._pick_custom_color)
        color_row.addWidget(self.custom_color_btn)

        # Превью выбранного цвета
        self.color_preview = QLabel("  ")
        self.color_preview.setFixedSize(28, 24)
        self.color_preview.setStyleSheet(
            f"background:{self.selected_color}; border:2px solid #555; border-radius:3px;"
        )
        color_row.addWidget(self.color_preview)
        color_row.addStretch()
        layout.addLayout(color_row)

        # Показать расшифрованный текст при редактировании
        self.show_plain_cb = QCheckBox("Показать расшифрованный текст")
        self.show_plain_cb.stateChanged.connect(self._toggle_plain)
        layout.addWidget(self.show_plain_cb)

        # Кнопки
        btn_row = QHBoxLayout()
        self.save_btn = QPushButton("Сохранить")
        self.save_btn.setStyleSheet("background:#4a90d9;color:white;padding:6px;border-radius:4px;")
        self.save_btn.clicked.connect(self._on_save)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(self.reject)

        btn_row.addWidget(self.save_btn)
        btn_row.addWidget(cancel_btn)
        layout.addLayout(btn_row)

    def _pick_preset(self, color: str):
        self.selected_color = color
        self.color_preview.setStyleSheet(
            f"background:{color}; border:2px solid #555; border-radius:3px;"
        )

    def _pick_custom_color(self):
        color = QColorDialog.getColor(QColor(self.selected_color), self, "Выберите цвет")
        if color.isValid():
            self._pick_preset(color.name())

    def _fill_categories(self):
        self.cat_combo.clear()
        self.cat_combo.addItem("— нет —", None)
        query = QSqlQuery("SELECT id, title FROM categories ORDER BY title")
        while query.next():
            self.cat_combo.addItem(query.value(1), query.value(0))

    # ──────────────── Загрузка данных ────────────────

    def _load_note(self):
        """Загружает данные существующей заметки."""
        query = QSqlQuery()
        query.prepare("SELECT title, content, cipher, category_id, color FROM notes WHERE id = ?")
        query.addBindValue(self.note_id)
        query.exec()

        if not query.next():
            return

        title, content, cipher, cat_id, color = (query.value(i) for i in range(5))
        if color:
            self._pick_preset(color)

        self.title_edit.setText(title)
        self.content_edit.setPlainText(content)  # храним зашифрованный текст

        # Выставляем шифр в комбобоксе
        idx = self.cipher_combo.findData(cipher)
        if idx >= 0:
            self.cipher_combo.setCurrentIndex(idx)

        # Выставляем категорию
        for i in range(self.cat_combo.count()):
            if self.cat_combo.itemData(i) == cat_id:
                self.cat_combo.setCurrentIndex(i)
                break

    # ──────────────── Показ расшифрованного текста ────────────────

    def _toggle_plain(self, state):
        if state == 2:  # Qt.CheckState.Checked
            cipher_id = self.cipher_combo.currentData()
            key = self.key_edit.text()
            encrypted = self.content_edit.toPlainText()
            try:
                plain = decrypt(encrypted, cipher_id, key)
                self.content_edit.setPlainText(plain)
                self.content_edit.setReadOnly(True)
            except Exception as e:
                QMessageBox.warning(self, "Ошибка расшифровки", str(e))
                self.show_plain_cb.setChecked(False)
        else:
            self.content_edit.setReadOnly(False)
            # При снятии галочки перезагружаем исходный зашифрованный текст
            if self.is_edit:
                self._load_note()

    # ──────────────── Сохранение ────────────────

    def _on_save(self):
        title = self.title_edit.text().strip()
        content = self.content_edit.toPlainText().strip()

        if not title:
            QMessageBox.warning(self, "Ошибка", "Введите заголовок заметки.")
            return
        if not content:
            QMessageBox.warning(self, "Ошибка", "Текст заметки не может быть пустым.")
            return

        cipher_id = self.cipher_combo.currentData()
        key = self.key_edit.text()
        cat_id = self.cat_combo.currentData()

        # Если чекбокс «показать расшифрованный» снят, контент уже зашифрован
        # (пользователь вводит обычный текст → шифруем при сохранении)
        if not self.show_plain_cb.isChecked():
            try:
                saved_content = encrypt(content, cipher_id, key)
            except Exception as e:
                QMessageBox.critical(self, "Ошибка шифрования", str(e))
                return
        else:
            # Пользователь видел расшифрованный текст — нам нужно снова зашифровать
            try:
                saved_content = encrypt(content, cipher_id, key)
            except Exception as e:
                QMessageBox.critical(self, "Ошибка шифрования", str(e))
                return

        query = QSqlQuery()
        if self.is_edit:
            query.prepare("""
                UPDATE notes
                SET title = ?, content = ?, cipher = ?, category_id = ?, color = ?
                WHERE id = ?
            """)
            query.addBindValue(title)
            query.addBindValue(saved_content)
            query.addBindValue(cipher_id)
            query.addBindValue(cat_id)
            query.addBindValue(self.selected_color)
            query.addBindValue(self.note_id)
        else:
            query.prepare("""
                INSERT INTO notes (user_id, category_id, title, content, cipher, color)
                VALUES (?, ?, ?, ?, ?, ?)
            """)
            query.addBindValue(self.user_id)
            query.addBindValue(cat_id)
            query.addBindValue(title)
            query.addBindValue(saved_content)
            query.addBindValue(cipher_id)
            query.addBindValue(self.selected_color)

        if query.exec():
            self.accept()
        else:
            QMessageBox.critical(self, "Ошибка БД", query.lastError().text())
