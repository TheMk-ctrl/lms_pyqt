"""
Окно входа / регистрации.
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QMessageBox, QTabWidget
)
from PyQt6.QtCore import Qt

from core.database import init_db
from core.auth import login_user, register_user
from ui.main_window import MainWindow


class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CryptoNotes — Вход")
        self.setFixedSize(360, 340)

        # Инициализируем БД при старте приложения
        if not init_db():
            QMessageBox.critical(self, "Ошибка", "Не удалось подключиться к базе данных.")

        self._init_ui()

    # ──────────────── UI ────────────────

    def _init_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("CryptoNotes")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(
            "font-size: 24px; font-weight: bold; margin: 10px 0;"
            "color: #2c3e50; letter-spacing: 1px;"
        )
        layout.addWidget(title)

        # Вкладки: Вход / Регистрация
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.tabs.addTab(self._build_login_tab(), "Вход")
        self.tabs.addTab(self._build_register_tab(), "Регистрация")

    def _build_login_tab(self) -> QWidget:
        w = QWidget()
        vbox = QVBoxLayout(w)

        vbox.addWidget(QLabel("Имя пользователя:"))
        self.login_name = QLineEdit()
        self.login_name.setPlaceholderText("Введите имя...")
        vbox.addWidget(self.login_name)

        vbox.addWidget(QLabel("Пароль:"))
        self.login_pass = QLineEdit()
        self.login_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.login_pass.setPlaceholderText("Введите пароль...")
        vbox.addWidget(self.login_pass)

        btn = QPushButton("Войти")
        btn.setStyleSheet("background: #4a90d9; color: white; padding: 6px; border-radius: 4px;")
        btn.clicked.connect(self._on_login)
        vbox.addWidget(btn)

        # Enter в поле пароля тоже запускает вход
        self.login_pass.returnPressed.connect(self._on_login)

        return w

    def _build_register_tab(self) -> QWidget:
        w = QWidget()
        vbox = QVBoxLayout(w)

        vbox.addWidget(QLabel("Имя пользователя:"))
        self.reg_name = QLineEdit()
        self.reg_name.setPlaceholderText("Придумайте имя...")
        vbox.addWidget(self.reg_name)

        vbox.addWidget(QLabel("Пароль:"))
        self.reg_pass = QLineEdit()
        self.reg_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.reg_pass.setPlaceholderText("Придумайте пароль...")
        vbox.addWidget(self.reg_pass)

        vbox.addWidget(QLabel("Повторите пароль:"))
        self.reg_pass2 = QLineEdit()
        self.reg_pass2.setEchoMode(QLineEdit.EchoMode.Password)
        self.reg_pass2.setPlaceholderText("Повторите пароль...")
        vbox.addWidget(self.reg_pass2)

        btn = QPushButton("Зарегистрироваться")
        btn.setStyleSheet("background: #27ae60; color: white; padding: 6px; border-radius: 4px;")
        btn.clicked.connect(self._on_register)
        vbox.addWidget(btn)

        return w

    # ──────────────── Обработчики ────────────────

    def _on_login(self):
        name = self.login_name.text().strip()
        password = self.login_pass.text()

        if not name or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля.")
            return

        ok, user_id = login_user(name, password)
        if ok:
            self._open_main(user_id, name)
        else:
            QMessageBox.critical(self, "Ошибка", "Неверное имя или пароль.")

    def _on_register(self):
        name = self.reg_name.text().strip()
        password = self.reg_pass.text()
        password2 = self.reg_pass2.text()

        if not name or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля.")
            return

        if password != password2:
            QMessageBox.warning(self, "Ошибка", "Пароли не совпадают.")
            return

        ok, msg = register_user(name, password)
        if ok:
            QMessageBox.information(self, "Успех", msg + "\nТеперь войдите.")
            self.tabs.setCurrentIndex(0)
            self.login_name.setText(name)
        else:
            QMessageBox.critical(self, "Ошибка", msg)

    def _open_main(self, user_id: int, username: str):
        self.main_win = MainWindow(user_id, username)
        self.main_win.show()
        self.close()
